-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 03, 2021 at 06:53 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quran`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `phone` bigint(20) UNSIGNED DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `email` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `whatsapp` text COLLATE utf8mb4_unicode_ci,
  `telegram` text COLLATE utf8mb4_unicode_ci,
  `youtube` text COLLATE utf8mb4_unicode_ci,
  `twitter` text COLLATE utf8mb4_unicode_ci,
  `facebook` text COLLATE utf8mb4_unicode_ci,
  `map` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `phone`, `address`, `email`, `created_at`, `updated_at`, `whatsapp`, `telegram`, `youtube`, `twitter`, `facebook`, `map`, `logo`) VALUES
(1, 968569878991, 'Abu Bakr Alseddiq Street, الفيحاء، المجمعة 15362', 'info@qm.sa', NULL, '2021-01-30 11:15:14', '011111111', 'http://quran.test/', 'http://quran.test/', 'http://quran.test/', 'http://quran.test/', 'http://quran.test/', '1612016114logo.svg');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `greets`
--

CREATE TABLE `greets` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `greets`
--

INSERT INTO `greets` (`id`, `title`, `image`, `content`, `created_at`, `updated_at`) VALUES
(1, 'إهداء يبقى عطره', '1611688623active.png', '<p>إهداء يبقى عطره</p>', '2021-01-26 16:17:03', '2021-01-26 16:17:03'),
(2, 'إهداء يبقى عطره2', '1611688677active.png', '<p>إهداء يبقى عطره</p>', '2021-01-26 16:17:57', '2021-01-26 16:21:30');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `imagedetail_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_08_16_153107_create_roles_table', 1),
(5, '2020_08_16_153216_create_permissions_table', 1),
(6, '2020_08_16_153443_create_users_roles_table', 1),
(7, '2020_08_16_155428_create_users_permissions_table', 1),
(8, '2020_08_16_155710_create_roles_permissions_table', 1),
(9, '2020_11_21_145410_create_posts_table', 1),
(10, '2020_11_22_152058_create_photos_table', 1),
(11, '2020_11_22_213147_create_videos_table', 1),
(12, '2020_11_23_184911_create_pages_table', 1),
(13, '2020_12_19_110304_create_numbers_table', 1),
(14, '2020_12_19_173522_create_images_table', 1),
(15, '2020_12_19_195346_create_sliders_table', 1),
(17, '2021_01_20_191925_add_title_and_body_to_slider_table', 2),
(18, '2021_01_20_194435_create_contacts_table', 3),
(19, '2021_01_20_220158_create_sponsers_table', 4),
(20, '2021_01_25_182920_add_to_contacts_table_social_row', 5),
(21, '2021_01_26_163946_create_reviews_table', 6),
(22, '2021_01_26_185258_create_greets_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `numbers`
--

CREATE TABLE `numbers` (
  `id` int(10) UNSIGNED NOT NULL,
  `field_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_1` bigint(20) NOT NULL,
  `field_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_2` bigint(20) NOT NULL,
  `field_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_3` bigint(20) NOT NULL,
  `field_4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_4` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `numbers`
--

INSERT INTO `numbers` (`id`, `field_1`, `value_1`, `field_2`, `value_2`, `field_3`, `value_3`, `field_4`, `value_4`, `created_at`, `updated_at`) VALUES
(1, 'عدد المجمعات القرآنية', 10, 'عدد الدور النسائية', 16, 'عدد الحلقات بنين وبنات', 254, 'عدد المعلمين والمعلمات', 2365, NULL, '2021-01-26 11:36:41');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL,
  `level` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `menu` tinyint(1) NOT NULL,
  `order` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `parent_id`, `level`, `user_id`, `title`, `content`, `created_at`, `updated_at`, `published`, `menu`, `order`, `slug`) VALUES
(1, 0, 1, 1, 'جمعية تحفيظ المجمعة', '<p>تحت إشراف وزارة الشؤون الإسلامية والدعوة والإرشاد وهي تخدم طلاب وطالبات المجمعة وحرمة و الأرطاوية والمراكز والهجر القريبة منها</p>', '2021-01-25 18:00:49', '2021-01-25 18:00:49', 1, 0, 0, 'gmaay-thfyth-almgmaa'),
(2, 0, 1, 1, 'الدعم', '<p><img src=\"./images/bankimage.png\" /> <!-- دي اللي هنربيت يامعلم --></p>\r\n\r\n<p><img src=\"./images/bank.png\" /></p>\r\n\r\n<p>الحساب العام SA14800001386010047319</p>\r\n\r\n<p>حساب الأوقاف SA14800001386010047319</p>\r\n\r\n<p>حساب المشاريع SA14800001386010047319</p>\r\n\r\n<p><a href=\"#\">رابط البنك</a></p>', '2021-02-03 15:50:45', '2021-02-03 15:50:45', 1, 1, 0, 'aldaam');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'دخول لوحة التحكم', 'control_panel_login', '2020-11-20 10:15:36', '2020-11-20 10:15:53'),
(2, 'مشاهدة الاعضاء', 'show_users', '2020-11-20 10:17:22', '2020-11-20 10:17:22'),
(3, 'اضافة عضو', 'add_user', '2020-11-20 10:17:43', '2020-11-20 10:17:43'),
(4, 'تعديل عضوية', 'edit_user', '2020-11-20 10:18:35', '2020-11-20 10:19:19'),
(5, 'حذف عضوية', 'delete_user', '2020-11-20 10:19:06', '2020-11-20 10:19:06'),
(6, 'عرض الادوار', 'show_roles', '2020-11-20 15:18:56', '2020-11-20 15:18:56'),
(7, 'اضافة دور', 'add_role', '2020-11-20 15:19:22', '2020-11-20 15:19:22'),
(8, 'تعديل دور', 'edit_role', '2020-11-20 15:19:52', '2020-11-20 15:19:52'),
(9, 'حذف دور', 'delete_role', '2020-11-20 15:20:23', '2020-11-20 15:20:23'),
(10, 'عرض الصلاحيات', 'show_permissions', '2020-11-20 15:21:02', '2020-11-20 15:21:02'),
(11, 'اضافة صلاحيه', 'add_permission', '2020-11-20 15:21:28', '2020-11-20 15:21:28'),
(12, 'تعديل صلاحيه', 'edit_permission', '2020-11-20 15:21:49', '2020-11-20 15:21:49'),
(13, 'حذف صلاحيه', 'delete_permission', '2020-11-20 15:22:11', '2020-11-20 15:22:11'),
(14, 'مشاهدة جميع الاخبار', 'view_news', '2020-11-21 17:07:50', '2020-11-21 17:07:50'),
(15, 'اضافة خبر', 'add_news', '2020-11-21 17:08:13', '2020-11-21 17:08:13'),
(16, 'تعديل خبر', 'edit_news', '2020-11-21 17:08:36', '2020-11-21 17:08:36'),
(17, 'حذف خبر', 'delete_news', '2020-11-21 17:09:00', '2020-11-21 17:09:00'),
(18, 'عرض مكتبة الصور', 'view_all_photos', '2020-11-22 17:52:49', '2020-11-22 17:52:49'),
(19, 'اضافة صور', 'add_photos', '2020-11-22 17:53:09', '2020-11-22 17:53:09'),
(20, 'تعديل الصور', 'edit_photos', '2020-11-22 17:53:47', '2020-11-22 17:53:47'),
(21, 'حذف الصور', 'delete_photos', '2020-11-22 17:54:08', '2020-11-22 17:54:08'),
(22, 'عرض الفيديوهات', 'view_videos', '2020-11-23 12:05:09', '2020-11-23 12:05:09'),
(23, 'اضافة فيديو', 'add_video', '2020-11-23 12:05:48', '2020-11-23 12:05:48'),
(24, 'تعديل فيديو', 'edit_video', '2020-11-23 12:06:11', '2020-11-23 12:06:11'),
(25, 'حذف فيديو', 'delete_video', '2020-11-23 12:06:37', '2020-11-23 12:06:37'),
(26, 'عرض الصفحات', 'view_pages', '2020-11-23 15:57:37', '2020-11-23 15:57:37'),
(27, 'اضافة صفحه', 'add_page', '2020-11-23 15:58:17', '2020-11-23 15:58:17'),
(28, 'تعديل صفحه', 'edit_page', '2020-11-23 15:58:38', '2020-11-23 15:58:38'),
(29, 'حذف صفحه', 'delete_page', '2020-11-23 15:59:11', '2020-11-23 15:59:11'),
(30, 'مشاهدة الارقام', 'view_number', '2020-12-19 08:26:48', '2020-12-19 08:26:48'),
(31, 'تعديل الارقام', 'edit_number', '2020-12-19 08:27:30', '2020-12-19 08:27:30'),
(32, 'عرض البانرات', 'view_slider', '2020-12-19 17:15:50', '2020-12-19 17:15:50'),
(33, 'اضافة بنر', 'add_slider', '2020-12-19 17:16:09', '2020-12-19 17:16:09'),
(34, 'تعديل بانر', 'edit_slider', '2020-12-19 17:16:27', '2020-12-19 17:17:04'),
(35, 'حذف بانر', 'delete_slider', '2020-12-19 17:16:55', '2020-12-19 17:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `filename`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '16116131290.png', 1, '2021-01-25 19:18:49', '2021-01-25 19:18:49'),
(2, '16116131291.png', 1, '2021-01-25 19:18:49', '2021-01-25 19:18:49'),
(3, '16116131292.png', 1, '2021-01-25 19:18:49', '2021-01-25 19:18:49');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `image`, `content`, `user_id`, `published`, `created_at`, `updated_at`) VALUES
(1, 'انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير', '1611609340news.png', '<p>انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير</p>', 1, 1, '2021-01-25 18:15:40', '2021-01-25 18:15:40'),
(2, 'انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير', '1611609363sadlan.png', '<p>انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير</p>', 1, 1, '2021-01-25 18:16:03', '2021-01-25 18:16:03'),
(3, 'انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير3', '1611668344news.png', '<p>انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير</p>', 1, 1, '2021-01-25 18:16:33', '2021-01-26 10:39:04'),
(4, 'انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير	4', '1611668034unnamed.png', '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>انتهاء بناء دارأم المؤمنين أم سلمة رضي الله عنها النسائية بحي البصيرةعلى نفقة فاعلة خير</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 1, 1, '2021-01-26 10:33:54', '2021-01-26 10:33:54');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `title`, `image`, `content`, `user_id`, `published`, `created_at`, `updated_at`) VALUES
(1, 'سماحة الشيخ / د. عبدالله بن جبرين (رحمه الله)', '1611680691shick.png', '<p>ما حصل من ثمرات هذه الجمعية بكثرة الحلقات وكثرة الذين حفظوا القرآن واتموا حفظه من الشباب والفتيات وقوة الإقبال على هذه الحلقات ،ونقول على المواطنين المساعدة بالتبرعات السخية لهم بما يكفل استمرارهم</p>\r\n\r\n<p>سماحة الشيخ / د. عبدالله بن جبرين (رحمه الله)</p>', 1, 1, '2021-01-26 14:04:51', '2021-01-26 14:46:07'),
(2, 'جهة 22', '1611680723shick.png', '<p>... وإني أدعوا جميع إخواني الوقوف مع الجمعية المباركة والتي تخدم كتاب الله .</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>فضيلة الشيخ / د. صالح السدلان (حفظه الله)</p>', 1, 1, '2021-01-26 14:05:23', '2021-01-26 14:07:47');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'مدير عام', 'ِAdministrator', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles_permissions`
--

CREATE TABLE `roles_permissions` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles_permissions`
--

INSERT INTO `roles_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `photo`, `user_id`, `published`, `created_at`, `updated_at`, `body`) VALUES
(1, 'بعطَائِكم نَسْتَمِرْ', '1611606008hero.png', 1, 1, '2021-01-20 16:29:33', '2021-01-25 17:20:08', 'كن شريكاً في أجر التلاوة والحفظ قال رسول الله : (من قرأ حرفاً من كتاب الله فله به حسنة، والحسنة بعشر أمثالها لا أقول (الم) حرف ولكن: ألف حرف ولام حرف، وميم حرف)'),
(2, 'الحمد لله الذي بنعمته تتم الصالحات', '16116061102225.jpg', 1, 1, '2021-01-25 17:21:50', '2021-01-25 17:52:59', 'نبشركم بانتهاء بناء دار الشيخ عبدالله بن حمد الحقيل رحمه الله النسائية على نفقته الخاصة بحي المستقبل بالمجمعة نسأل الله تعالى أن يجزيه خير الجزاء وأن يسكنه الفردوس الأعلى من الجنة والشكر موصول لذريته على جهودهم ومتابعتهم لاحرم الله الجميع الأجر');

-- --------------------------------------------------------

--
-- Table structure for table `sponsers`
--

CREATE TABLE `sponsers` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sponsers`
--

INSERT INTO `sponsers` (`id`, `title`, `image`, `url`, `created_at`, `updated_at`) VALUES
(1, 'التدريب1', '1611614278unnamed.png', 'http://quran.test/', '2021-01-20 19:21:10', '2021-01-25 19:37:58'),
(2, 'الرعاه 2', '1611614308unnamed.png', 'http://quran.test/', '2021-01-25 19:38:28', '2021-01-25 19:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mohamed', 'visionscube.com@gmail.com', NULL, '$2y$10$474NI3ubRLjl49eOxBH8puESjQ3yVfOAf59L6bX6Xo.BDSagOoX1a', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_permissions`
--

CREATE TABLE `users_permissions` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_roles`
--

CREATE TABLE `users_roles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_roles`
--

INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `code`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'صدقة خفية', 'https://www.youtube.com/embed/XioOysDgjF4', 1, '2021-01-25 19:19:44', '2021-01-25 19:27:22'),
(2, 'صدقة خفية2', 'https://www.youtube.com/embed/XioOysDgjF4', 1, '2021-01-25 19:19:55', '2021-01-25 19:27:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `greets`
--
ALTER TABLE `greets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `numbers`
--
ALTER TABLE `numbers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsers`
--
ALTER TABLE `sponsers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD PRIMARY KEY (`user_id`,`permission_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `greets`
--
ALTER TABLE `greets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `numbers`
--
ALTER TABLE `numbers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sponsers`
--
ALTER TABLE `sponsers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
